#ifndef UTIL_SHM_H
#define UTIL_SHM_H

int create_shm_file(void);
int allocate_shm_file(size_t size);

#endif
